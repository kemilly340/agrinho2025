let gridSize = 40;
let cols, rows;

let player1, player2;
let fruits = [];
let powerUps = [];
let maxFruits = 10;
let gameTime = 60 * 1000; // 60 segundos
let startTime;
let gameEnded = false;
let particles = [];

let fruitEmojis = ['🍎', '🍌', '🍇', '🍓', '🍉'];
let powerUpEmojis = ['⚡', '🛡️', '🌟'];
let backgroundColors = ['#E1F5FE', '#E8F5E9', '#FFF3E0'];

function setup() {
  createCanvas(800, 600);
  cols = floor(width / gridSize);
  rows = floor(height / gridSize);

  player1 = { 
    x: 1, 
    y: 1, 
    score: 0, 
    emoji: '👨‍🌾',
    speed: 1,
    invincible: 0
  };
  
  player2 = { 
    x: cols - 2, 
    y: rows - 2, 
    score: 0, 
    emoji: '👩‍🌾',
    speed: 1,
    invincible: 0
  };

  for (let i = 0; i < maxFruits; i++) {
    fruits.push(randomFruitPosition());
  }

  // Power-ups aparecem a cada 15 segundos
  setInterval(() => {
    if (!gameEnded && powerUps.length < 3) {
      powerUps.push(randomPowerUpPosition());
    }
  }, 15000);

  startTime = millis();
  textAlign(CENTER, CENTER);
  textSize(20);
  noStroke();
  frameRate(60);
}

function draw() {
  // Fundo gradiente
  drawGradientBackground();
  
  if (!gameEnded) {
    // Atualizar partículas
    updateParticles();
    
    // Mostrar frutas
    drawFruits();
    
    // Mostrar power-ups
    drawPowerUps();
    
    // Mostrar jogadores
    drawPlayer(player1);
    drawPlayer(player2);
    
    // Mostrar placar e tempo
    drawHUD();
    
    // Verificar coletáveis
    checkCollectables(player1);
    checkCollectables(player2);
    
    // Verificar tempo
    checkGameTime();
    
  } else {
    showGameOver();
  }
}

function drawGradientBackground() {
  for (let y = 0; y < height; y++) {
    let inter = map(y, 0, height, 0, 1);
    let c = lerpColor(color(backgroundColors[0]), color(backgroundColors[1]), inter);
    stroke(c);
    line(0, y, width, y);
  }
}

function drawFruits() {
  textSize(gridSize * 0.8);
  for (let f of fruits) {
    text(f.emoji, f.x * gridSize + gridSize / 2, f.y * gridSize + gridSize / 2);
  }
}

function drawPowerUps() {
  textSize(gridSize * 0.7);
  for (let p of powerUps) {
    push();
    translate(p.x * gridSize + gridSize / 2, p.y * gridSize + gridSize / 2);
    rotate(frameCount * 0.05);
    text(p.emoji, 0, 0);
    pop();
  }
}

function drawPlayer(p) {
  push();
  textSize(gridSize);
  if (p.invincible > 0 && frameCount % 10 < 5) {
    fill(255, 255, 0);
  }
  text(p.emoji, p.x * gridSize + gridSize / 2, p.y * gridSize + gridSize / 2);
  pop();
}

function drawHUD() {
  fill(0, 100);
  rect(0, 0, width, 40);
  
  fill(255);
  textSize(24);
  text(`👨‍🌾: ${player1.score}`, width / 4, 20);
  text(`👩‍🌾: ${player2.score}`, (width / 4) * 3, 20);
  
  let elapsed = millis() - startTime;
  let remaining = max(0, floor((gameTime - elapsed) / 1000));
  text(`⏱️ ${remaining}s`, width / 2, 20);
}

function updateParticles() {
  for (let i = particles.length - 1; i >= 0; i--) {
    particles[i].x += particles[i].vx;
    particles[i].y += particles[i].vy;
    particles[i].life--;
    
    if (particles[i].life > 0) {
      fill(255, particles[i].life * 8);
      noStroke();
      ellipse(particles[i].x, particles[i].y, particles[i].life/3);
    } else {
      particles.splice(i, 1);
    }
  }
}

function checkCollectables(player) {
  // Verificar frutas
  for (let i = fruits.length - 1; i >= 0; i--) {
    if (player.x === fruits[i].x && player.y === fruits[i].y) {
      fruits.splice(i, 1);
      player.score += 1;
      createParticles(player.x, player.y, color(255, 215, 0));
      fruits.push(randomFruitPosition());
      break;
    }
  }
  
  // Verificar power-ups
  for (let i = powerUps.length - 1; i >= 0; i--) {
    if (player.x === powerUps[i].x && player.y === powerUps[i].y) {
      applyPowerUp(player, powerUps[i].type);
      createParticles(player.x, player.y, color(255, 0, 255));
      powerUps.splice(i, 1);
      break;
    }
  }
}

function applyPowerUp(player, type) {
  switch(type) {
    case 0: // ⚡ Velocidade
      player.speed = 2;
      setTimeout(() => { player.speed = 1; }, 5000);
      break;
    case 1: // 🛡️ Invencibilidade
      player.invincible = 180; // 3 segundos (60 frames/sec)
      break;
    case 2: // 🌟 Pontos extras
      player.score += 5;
      break;
  }
}

function checkGameTime() {
  let elapsed = millis() - startTime;
  if (elapsed >= gameTime) {
    gameEnded = true;
    // Criar explosão de partículas
    for (let i = 0; i < 100; i++) {
      particles.push({
        x: random(width),
        y: random(height),
        vx: random(-5, 5),
        vy: random(-5, 5),
        life: random(30, 60),
        color: color(random(255), random(255), random(255))
      });
    }
  }
}

function showGameOver() {
  // Fundo escuro semi-transparente
  fill(0, 200);
  rect(0, 0, width, height);
  
  fill(255);
  textSize(48);
  
  let winnerText;
  if (player1.score > player2.score) {
    winnerText = "👨‍🌾 Jogador 1 Venceu!";
  } else if (player2.score > player1.score) {
    winnerText = "👩‍🌾 Jogador 2 Venceu!";
  } else {
    winnerText = "🏆 Empate!";
  }
  
  text(winnerText, width / 2, height / 2 - 50);
  textSize(32);
  text(`Placar Final: ${player1.score} - ${player2.score}`, width / 2, height / 2 + 20);
  
  textSize(24);
  text("Pressione R para reiniciar", width / 2, height / 2 + 80);
}

function createParticles(x, y, col) {
  for (let i = 0; i < 15; i++) {
    particles.push({
      x: x * gridSize + gridSize / 2,
      y: y * gridSize + gridSize / 2,
      vx: random(-3, 3),
      vy: random(-3, 3),
      life: random(20, 40),
      color: col || color(random(255), random(255), random(255))
    });
  }
}

function randomFruitPosition() {
  return {
    x: floor(random(cols)),
    y: floor(random(rows)),
    emoji: random(fruitEmojis)
  };
}

function randomPowerUpPosition() {
  return {
    x: floor(random(cols)),
    y: floor(random(rows)),
    emoji: random(powerUpEmojis),
    type: floor(random(3))
  };
}

function keyPressed() {
  if (gameEnded && key === 'r') {
    resetGame();
    return;
  }

  if (gameEnded) return;

  // Jogador 1: WASD
  let nx1 = player1.x;
  let ny1 = player1.y;
  if (key === 'W' || key === 'w') ny1 -= player1.speed;
  else if (key === 'S' || key === 's') ny1 += player1.speed;
  else if (key === 'A' || key === 'a') nx1 -= player1.speed;
  else if (key === 'D' || key === 'd') nx1 += player1.speed;

  if (insideGrid(nx1, ny1)) {
    player1.x = nx1;
    player1.y = ny1;
  }

  // Jogador 2: setas
  let nx2 = player2.x;
  let ny2 = player2.y;
  if (keyCode === UP_ARROW) ny2 -= player2.speed;
  else if (keyCode === DOWN_ARROW) ny2 += player2.speed;
  else if (keyCode === LEFT_ARROW) nx2 -= player2.speed;
  else if (keyCode === RIGHT_ARROW) nx2 += player2.speed;

  if (insideGrid(nx2, ny2)) {
    player2.x = nx2;
    player2.y = ny2;
  }
}

function resetGame() {
  fruits = [];
  powerUps = [];
  particles = [];
  
  for (let i = 0; i < maxFruits; i++) {
    fruits.push(randomFruitPosition());
  }
  
  player1 = { 
    x: 1, 
    y: 1, 
    score: 0, 
    emoji: '👨‍🌾',
    speed: 1,
    invincible: 0
  };
  
  player2 = { 
    x: cols - 2, 
    y: rows - 2, 
    score: 0, 
    emoji: '👩‍🌾',
    speed: 1,
    invincible: 0
  };
  
  startTime = millis();
  gameEnded = false;
}

function insideGrid(x, y) {
  return x >= 0 && x < cols && y >= 0 && y < rows;
}